# SETU — Unified Police-Assistance Platform (Prototype)
### Team CopVision · SIH SS-07

Full-stack demo: officer login, FIR/complaint filing and management, officer
directory + attendance, and three AI modules (Identity Resolution across
disconnected databases, Indian-language NLP, Speech-to-Text) — wired *into*
the complaint-filing workflow, not just standalone demo widgets.

## Run it

```
npm install
npm start
```

Open **http://localhost:3000** in Chrome or Edge (Speech-to-Text needs a
Chromium-based browser).

**Demo login:** Badge `INSP001` · Password `setu123`
(3 more demo officers in `data/officers.json`, same password.)

## What's in it

- **Login** — badge ID + password (demo-only auth, see note below)
- **File Complaint** — complainant, accused, complaint type (Robbery, Phone
  Theft, Vehicle Theft, Threat/Harassment, Missing Person, Cybercrime,
  Other), and a description you can type *or speak* (mic button on the form
  uses the same Speech-to-Text engine as the standalone module)
- **On submit, automatically:**
  - Indian-Language NLP analyses the description (language + entities + risk
    keywords)
  - if an accused name was given, Identity Resolution searches for it across
    the 3 mock databases
  - both results are stored on the complaint record and shown immediately
- **Manage Complaints** — table of every filed case, expandable to see the
  AI signals, with a status dropdown (Open / Under Investigation / Closed)
- **Officers & Attendance** — directory table (badge, name, rank, station,
  contact) + daily present/absent/leave marking
- **Identity Resolution / Indian-Language NLP / Speech-to-Text** — also
  available as standalone pages, for demoing each capability on its own

## Architecture

```
setu-backend/
  server.js          Express app — all routes + serves the frontend
  lib/auth.js          Demo login check against officers.json
  lib/store.js          Read/write helpers for the JSON "database" files
  lib/match.js           Levenshtein fuzzy matching + identity resolution
  lib/nlp.js              Multi-script language detection + entity/risk extraction
  data/*.json               officers, complaints, attendance, and 3 mock police DBs
  public/index.html      Frontend — login + app shell, calls the API below
```

### API

| Endpoint | Method | What it does |
|---|---|---|
| `/api/health` | GET | Backend status check |
| `/api/login` | POST `{id, password}` | Officer login |
| `/api/officers` | GET | Officer directory |
| `/api/attendance?date=&officerId=` | GET | Attendance records, filterable |
| `/api/attendance` | POST `{officerId, date, status}` | Mark attendance |
| `/api/complaints/types` | GET | List of complaint types |
| `/api/complaints?status=` | GET | List complaints, filterable |
| `/api/complaints/:id` | GET | Single complaint |
| `/api/complaints` | POST | File a complaint — runs NLP + Identity Resolution automatically |
| `/api/complaints/:id` | PATCH `{status}` | Update complaint status |
| `/api/identity/search?q=<name>` | GET | Fuzzy-match a name across the 3 mock DBs |
| `/api/nlp/analyze` | POST `{text}` | Language detection + entity/risk extraction |

Complaints and attendance are persisted to the JSON files in `data/` (written
on every change) — restart the server and the data is still there. Delete
the file contents (`[]`) any time to reset the demo.

## Be upfront about this when presenting

- **Login** is a demo shortcut: plain-text password match, no hashing, no
  sessions/JWT, no route protection on the backend (the frontend just hides
  the UI if you're not "logged in"). Fine for a prototype; say so if asked.
- **Identity Resolution** — the fuzzy-matching algorithm is genuinely
  functional. Only the *data* (3 mock DBs) is fake.
- **Speech-to-Text** — 100% real, live browser transcription, no backend
  involved by design.
- **NLP** — rule-based dictionary lookups (Hindi, English, Tamil entities;
  Devanagari/Tamil/Telugu/Bengali/Kannada/Gujarati script *detection*)
  standing in for a real model. The natural next step is swapping the
  inside of `lib/nlp.js` for a call to IndicBERT / Bhashini without
  touching the API contract or frontend at all.

## Extending it

Each module sits behind its own route, so any one of them — NLP, identity
resolution, or even auth/storage — can be swapped for a real service
independently. Adding a new complaint type: edit `COMPLAINT_TYPES` in
`server.js`. Adding a new officer: add a row to `data/officers.json`.

## Updated demo data & language coverage
- Identity Resolution now uses a larger set of fictional records across Police, Transport and Civil databases.
- The NLP prototype recognizes 10 language/script categories: Hindi, English, Tamil, Telugu, Bengali, Kannada, Gujarati, Punjabi (Gurmukhi), Malayalam, plus mixed-script inputs.
- Complaints are persisted to `data/complaints.json`. Each saved complaint stores the complainant details, accused name, description, officer, NLP result, identity-resolution result and case-status history.
- Demo records are fictional and intended only for academic/prototype use.
