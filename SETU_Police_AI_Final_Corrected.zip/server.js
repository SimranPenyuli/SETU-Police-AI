const express = require('express');
const path = require('path');
const fs = require('fs');
const { resolveIdentity } = require('./lib/match');
const { analyze } = require('./lib/nlp');
const { readJSON, writeJSON } = require('./lib/store');
const { login } = require('./lib/auth');
const { translateText } = require('./lib/translate');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function loadDB(file) {
  return JSON.parse(fs.readFileSync(path.join(__dirname, 'data', file), 'utf-8'));
}

/* ---------------- health ---------------- */
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'SETU backend' });
});

/* ---------------- auth ---------------- */
app.post('/api/login', (req, res) => {
  const { id, password } = req.body || {};
  const officer = login((id || '').trim(), password || '');
  if (!officer) return res.status(401).json({ error: 'Invalid badge ID or password' });
  res.json({ officer });
});

/* ---------------- identity resolution ---------------- */
app.get('/api/identity/search', (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.status(400).json({ error: 'Missing query param "q"' });

  const db1 = loadDB('db1_police.json');
  const db2 = loadDB('db2_transport.json');
  const db3 = loadDB('db3_civil.json');
  const db4 = loadDB('db4_criminal.json');

  res.json(resolveIdentity(q, db1, db2, db3, db4));
});

/* ---------------- NLP ---------------- */
app.post('/api/nlp/analyze', async (req, res) => {
  const text = (req.body && req.body.text || '').trim();
  if (!text) return res.status(400).json({ error: 'Missing "text" in request body' });

  const result = analyze(text);

  // Best-effort translation to Hindi — never let a translation failure
  // (e.g. offline, endpoint down) break the actual NLP analysis.
  try {
    result.translationHi = await translateText(text, 'hi');
  } catch (e) {
    result.translationHi = null;
    result.translationError = 'Translation service unavailable (needs internet access on the server).';
  }

  res.json(result);
});

/* Standalone translation endpoint, reusable elsewhere (e.g. complaint descriptions) */
app.post('/api/translate', async (req, res) => {
  const text = (req.body && req.body.text || '').trim();
  const target = (req.body && req.body.target) || 'hi';
  if (!text) return res.status(400).json({ error: 'Missing "text" in request body' });
  try {
    const translated = await translateText(text, target);
    res.json({ translated, target });
  } catch (e) {
    res.status(502).json({ error: 'Translation service unavailable' });
  }
});

/* ---------------- officers (ERP-style directory) ---------------- */
app.get('/api/officers', (req, res) => {
  const officers = readJSON('officers.json').map(({ password, ...safe }) => safe);
  res.json(officers);
});

/* ---------------- attendance ---------------- */
app.get('/api/attendance', (req, res) => {
  const { date, officerId } = req.query;
  let records = readJSON('attendance.json');
  if (date) records = records.filter(r => r.date === date);
  if (officerId) records = records.filter(r => r.officerId === officerId);
  if (officerId && !date) records = records.sort((a,b) => String(b.date).localeCompare(String(a.date))).slice(0, 10);
  res.json(records);
});

app.post('/api/attendance', (req, res) => {
  return res.status(403).json({ error: 'Attendance is read-only in SETU. Officers cannot mark or modify attendance.' });
});

/* ---------------- complaints / FIR management ---------------- */
const COMPLAINT_TYPES = ['Robbery', 'Phone Theft', 'Vehicle Theft', 'Threat / Harassment', 'Missing Person', 'Cybercrime', 'Other'];

app.get('/api/complaints/types', (req, res) => res.json(COMPLAINT_TYPES));

app.get('/api/complaints', (req, res) => {
  const { status } = req.query;
  let records = readJSON('complaints.json');
  if (status) records = records.filter(r => r.status === status);
  res.json(records.sort((a, b) => new Date(b.filedAt) - new Date(a.filedAt)));
});

app.get('/api/complaints/:id', (req, res) => {
  const records = readJSON('complaints.json');
  const rec = records.find(r => r.id === req.params.id);
  if (!rec) return res.status(404).json({ error: 'Not found' });
  res.json(rec);
});

app.post('/api/complaints', (req, res) => {
  const {
    complaintType, complainantName, complainantContact, complainantAddress,
    accusedName, description, filedByOfficerId,
  } = req.body || {};

  if (!complaintType || !complainantName || !description || !filedByOfficerId) {
    return res.status(400).json({ error: 'complaintType, complainantName, description and filedByOfficerId are required' });
  }

  const officers = readJSON('officers.json');
  const officer = officers.find(o => o.id === filedByOfficerId);
  if (!officer) return res.status(400).json({ error: 'Unknown filedByOfficerId' });

  // AI modules run automatically as part of filing — not a separate demo step.
  const nlpResult = analyze(description);

  let identityResult = null;
  if (accusedName && accusedName.trim()) {
    const db1 = loadDB('db1_police.json');
    const db2 = loadDB('db2_transport.json');
    const db3 = loadDB('db3_civil.json');
    const db4 = loadDB('db4_criminal.json');
    identityResult = resolveIdentity(accusedName.trim(), db1, db2, db3, db4);
  }

  const records = readJSON('complaints.json');
  const id = 'FIR-' + String(1000 + records.length + 1);
  const record = {
    id,
    recordType: 'Police Complaint / FIR Intake Record',
    complaintType,
    complainantName,
    complainantContact: complainantContact || '',
    complainantAddress: complainantAddress || '',
    accusedName: accusedName || '',
    description,
    filedByOfficerId,
    filedByOfficerName: officer.name,
    status: 'Open',
    caseHistory: [{ status: 'Open', changedAt: new Date().toISOString(), changedByOfficerId: filedByOfficerId }],
    filedAt: new Date().toISOString(),
    nlpResult,
    identityResult,
  };
  records.push(record);
  writeJSON('complaints.json', records);
  res.status(201).json(record);
});

app.patch('/api/complaints/:id', (req, res) => {
  const { status } = req.body || {};
  const valid = ['Open', 'Under Investigation', 'Closed'];
  if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });

  const records = readJSON('complaints.json');
  const idx = records.findIndex(r => r.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'Not found' });
  records[idx].status = status;
  records[idx].caseHistory = Array.isArray(records[idx].caseHistory) ? records[idx].caseHistory : [];
  records[idx].caseHistory.push({ status, changedAt: new Date().toISOString() });
  writeJSON('complaints.json', records);
  res.json(records[idx]);
});

app.listen(PORT, () => {
  console.log(`SETU backend running at http://localhost:${PORT}`);
});
